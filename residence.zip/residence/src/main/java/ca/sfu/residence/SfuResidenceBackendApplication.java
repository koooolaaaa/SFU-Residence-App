package ca.sfu.residence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SfuResidenceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SfuResidenceBackendApplication.class, args);
	}

}
